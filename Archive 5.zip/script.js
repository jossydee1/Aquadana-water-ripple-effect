$('#ripple').ripples({
	resolution: 512,
	dropRadius: 20,
	perturbance: 0,
});
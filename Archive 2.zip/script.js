$('#ripple').ripples({
	resolution: 512,
	dropRadius: 100,
	perturbance: 5,
});
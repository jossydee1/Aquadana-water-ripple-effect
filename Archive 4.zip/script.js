$('#ripple').ripples({
	resolution: 52,
	dropRadius: 20,
	perturbance: 0.04,
});